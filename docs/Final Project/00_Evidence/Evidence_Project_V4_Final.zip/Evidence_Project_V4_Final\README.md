# Evidence Project V4 — Final

Indonesia E-Commerce Sales Analysis — final visual evidence package.

- Source archive: `C:\Users\maula\Downloads\Evidence_Project_V4.zip`
- Output folder: `C:\Users\maula\Downloads\Evidence_Project_V4_Final`
- Final archive: `C:\Users\maula\Downloads\Evidence_Project_V4_Final.zip`

## Full contents

### Audit_Files/ (source audit files, preserved byte-for-byte)
1. `01_Date_Transformation_Audit.csv`
2. `02_Payment_Transformation_Audit.csv`
3. `03_Raw_Clean_Reconciliation_V4.txt`
4. `04_Evidence_README.md` (original audit README, left unchanged)
5. `05_SHA256_Manifest.csv` (original manifest of files 1–4, left unchanged)

### Visual_Evidence/
1. `01_Source_Dataset.png` — Kaggle dataset source page and source information
2. `02_Raw_Dataset.png` — Raw dataset, 18,868 × 19, and first-5-row preview
3. `03_Clean_Dataset.png` — Clean dataset, 18,868 × 22, and first-5-row preview
4. `04_Date_Transformation_Audit.png` — 18,644 valid, 188 missing, 36 invalid
5. `05_Payment_Transformation_Audit.png` — 283 missing mapped, 103 COD mapped
6. `06_Final_Reconciliation.png` — full reconciliation report and 6/6 PASS
7. `07_Project_Structure.png` — final folder structure

### Root
- `README.md` — this file (full contents listing)
- `FINAL_EVIDENCE_REPORT.md` — final report (locations, screenshots, status, limitations)
- `SHA256_MANIFEST_FINAL.csv` — SHA-256 for every file except the manifest itself

## Preserved audit figures
- Raw: 18,868 rows × 19 columns; Clean: 18,868 rows × 22 columns
- Matched order IDs: 18,868; missing 0; extra 0
- Date: 18,644 valid preserved, 188 missing filled, 36 invalid replaced, 224 total repaired, 0 clean missing dates
- Payment: 283 raw missing → `Tidak Diketahui`; 103 raw COD → `COD (Bayar di Tempat)`; 0 mismatches
- Reconciliation: 6 checks, 6 passed, 0 failed

## Notes
- The five files in `Audit_Files/` were not edited. Their SHA-256 values match the original `05_SHA256_Manifest.csv` (files 1–4).
- Only the two documented payment transformations (missing → `Tidak Diketahui`, COD → `COD (Bayar di Tempat)`) are claimed. Other payment labels are not claimed to be normalised.
- The original raw CSV (`indonesia_ecommerce_sales_challenging.csv`) was not present on this machine. The raw preview was reconstructed exactly from the preserved `order_date_raw` column in the Clean dataset. See `FINAL_EVIDENCE_REPORT.md`.
