
# Evidence Project V4

## Purpose
Documentation of Raw vs Clean Dataset reconciliation.

## Contents
1. Date Transformation Audit
2. Payment Transformation Audit
3. Raw vs Clean Reconciliation V4
4. SHA-256 Manifest

## Dataset
- Raw: 18,868 rows, 19 columns
- Clean: 18,868 rows, 22 columns

## Date Transformation
- 18,644 valid dates preserved.
- 188 missing dates filled from Waktu Pesanan Dibuat.
- 36 invalid dates replaced from Waktu Pesanan Dibuat.
- No missing dates remain in Clean Dataset.

## Payment Transformation
- 283 missing payment methods categorized as Tidak Diketahui.
- Raw COD mapped to COD (Bayar di Tempat).
- Other payment categories retained according to the cleaning output.

## Audit
All six reconciliation checks must pass.

Date comparisons use calendar dates because Clean order_date
stores dates without the time component.

## Integrity
The SHA-256 manifest covers the evidence files created before
the manifest itself. It excludes itself to avoid a
self-referential hash.
